<?php

$conn = mysqli_connect('localhost','root','','sujoy') or die('connection failed');

?>