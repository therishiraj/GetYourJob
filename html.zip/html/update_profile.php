<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(isset($_POST['update_profile'])){
   $update_name = mysqli_real_escape_string($conn, $_POST['update_name']);
   $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);
   $update_first_name = mysqli_real_escape_string($conn, $_POST['update_first_name']);
   $update_middle_name = mysqli_real_escape_string($conn, $_POST['update_middle_name']);
   $update_last_name = mysqli_real_escape_string($conn, $_POST['update_last_name']);
   $update_dob = mysqli_real_escape_string($conn, $_POST['update_dob']);
   $update_mobile = mysqli_real_escape_string($conn, $_POST['update_mobile']);
   $update_parent_name = mysqli_real_escape_string($conn, $_POST['update_parent_name']);
   $update_country = mysqli_real_escape_string($conn, $_POST['update_country']);
   $update_address = mysqli_real_escape_string($conn, $_POST['update_address']);
   $update_city = mysqli_real_escape_string($conn, $_POST['update_city']);
   $update_state = mysqli_real_escape_string($conn, $_POST['update_state']);
   $update_zip_code = mysqli_real_escape_string($conn, $_POST['update_zip_code']);
   $update_indian_citizen = mysqli_real_escape_string($conn, $_POST['indian_citizen']);
   $update_position = mysqli_real_escape_string($conn, $_POST['update_position']);
   $update_high_school = mysqli_real_escape_string($conn, $_POST['update_high_school']);
   $update_graduated_highschool = mysqli_real_escape_string($conn, $_POST['update_graduated_highschool']);
   $update_college = mysqli_real_escape_string($conn, $_POST['update_college']);
   $update_area_study = mysqli_real_escape_string($conn, $_POST['update_area_study']);
   $update_graduated_college = mysqli_real_escape_string($conn, $_POST['update_graduated_college']);
   $update_skills = mysqli_real_escape_string($conn, $_POST['update_skills']);
   $update_qualifications = mysqli_real_escape_string($conn, $_POST['update_qualifications']);
   
   mysqli_query($conn, "UPDATE `user_form` SET 
      name = '$update_name', 
      email = '$update_email', 
      first_name = '$update_first_name', 
      middle_name = '$update_middle_name', 
      last_name = '$update_last_name', 
      dob = '$update_dob', 
      mobile = '$update_mobile', 
      parent_name = '$update_parent_name',
      address = '$update_address',
      city = '$update_city',
      country = '$update_country',  -- Fixed: Wrapped `country` in backticks
      state = '$update_state',
      zip_code = '$update_zip_code',
      indian_citizen = '$update_indian_citizen',  -- Added field for Indian citizen
      position = '$update_position',
      high_school = '$update_high_school',
      graduated_highschool = '$update_graduated_highschool',
      college = '$update_college',
      area_study = '$update_area_study',
      graduated_college = '$update_graduated_college',
      skills = '$update_skills',
      qualifications = '$update_qualifications'
      WHERE id = '$user_id'") or die('query failed');


   $old_pass = $_POST['old_pass'];
   $update_pass = mysqli_real_escape_string($conn, md5($_POST['update_pass']));
   $new_pass = mysqli_real_escape_string($conn, md5($_POST['new_pass']));
   $confirm_pass = mysqli_real_escape_string($conn, md5($_POST['confirm_pass']));

   if(!empty($update_pass) || !empty($new_pass) || !empty($confirm_pass)){
      if($update_pass != $old_pass){
         $message[] = 'old password not matched!';
      }elseif($new_pass != $confirm_pass){
         $message[] = 'confirm password not matched!';
      }else{
         mysqli_query($conn, "UPDATE `user_form` SET password = '$confirm_pass' WHERE id = '$user_id'") or die('query failed');
         $message[] = 'password updated successfully!';
      }
   }

   $update_image = $_FILES['update_image']['name'];
   $update_image_size = $_FILES['update_image']['size'];
   $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
   $update_image_folder = 'uploaded_img/'.$update_image;

   if(!empty($update_image)){
      if($update_image_size > 2000000){
         $message[] = 'image is too large';
      }else{
         $image_update_query = mysqli_query($conn, "UPDATE `user_form` SET image = '$update_image' WHERE id = '$user_id'") or die('query failed');
         if($image_update_query){
            move_uploaded_file($update_image_tmp_name, $update_image_folder);
         }
         $message[] = 'image updated successfully!';
      }
   }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Profile</title>

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="update-profile">
   <?php
      $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select) > 0){
         $fetch = mysqli_fetch_assoc($select);
      }
   ?>

   <form action="./job/index.php" method="post" enctype="multipart/form-data">
      <?php
         if($fetch['image'] == ''){
            echo '<img src="images/default-avatar.png">';
         }else{
            echo '<img src="uploaded_img/'.$fetch['image'].'">';
         }
         if(isset($message)){
            foreach($message as $message){
               echo '<div class="message">'.$message.'</div>';
            }
         }
      ?>
      <div class="flex">
         <div class="inputBox">
            <span>Username:</span>
            <input type="text" name="update_name" value="<?php echo $fetch['name']; ?>" class="box">
            <span>Your Email:</span>
            <input type="email" name="update_email" value="<?php echo $fetch['email']; ?>" class="box">
            <span>Update Your Pic:</span>
            <input type="file" name="update_image" accept="image/jpg, image/jpeg, image/png" class="box">
            <span>First Name:</span>
            <input type="text" name="update_first_name" value="<?php echo $fetch['first_name']; ?>" class="box">
            <span>Last Name:</span>
            <input type="text" name="update_last_name" value="<?php echo $fetch['last_name']; ?>" class="box">
            <span>Mobile No.:</span>
            <input type="text" name="update_mobile" value="<?php echo $fetch['mobile']; ?>" class="box">
            <span>Country:</span>
            <select name="update_country" class="box">
               <option value="Bharat" <?php if($fetch['country'] == 'USA') echo 'selected'; ?>>Bharat</option>
               <option value="Canada" <?php if($fetch['country'] == 'Canada') echo 'selected'; ?>>Canada</option>
               <option value="UK" <?php if($fetch['country'] == 'UK') echo 'selected'; ?>>UK</option>
               <option value="Australia" <?php if($fetch['country'] == 'Australia') echo 'selected'; ?>>Australia</option>
               <!-- Add more options as needed -->
            </select>
            <span>City:</span>
            <input type="text" name="update_city" value="<?php echo $fetch['city']; ?>" class="box">
            <span>Zip Code/Postal:</span>
            <input type="text" name="update_zip_code" value="<?php echo $fetch['zip_code']; ?>" class="box">
            <span>Position Applying For:</span>
            <select name="update_position" class="box">
               <option value="">Select a Position</option> <!-- Placeholder option -->
               <option value="Position 1" <?php if($fetch['country'] == 'USA') echo 'selected'; ?>>Position 1</option>
               <option value="Position 2" <?php if($fetch['country'] == 'Canada') echo 'selected'; ?>>Position 2</option>
               <option value="Position 3" <?php if($fetch['country'] == 'UK') echo 'selected'; ?>>Position 3</option>
               <!-- Add more options as needed -->
            </select>
            <span>Graduated from High School?</span>
            <select name="update_graduated_highschool" class="box">
               <option value="">Select</option> <!-- Placeholder option -->
               <option value="Yes" <?php if($fetch['graduated_highschool'] == 'USA') echo 'selected'; ?>>Yes</option>
               <option value="No" <?php if($fetch['graduated_highschool'] == 'Canada') echo 'selected'; ?>>No</option>
            </select>           
            <span>Area of Study/Degree</span>
            <input type="text" name="update_area_study" value="<?php echo $fetch['area_study']; ?>" class="box">
            <span>Skills</span>
            <textarea name="update_skills" class="box" rows="4" cols="50"><?php echo $fetch['skills']; ?></textarea>




         </div>
         <div class="inputBox">
            <input type="hidden" name="old_pass" value="<?php echo $fetch['password']; ?>">
            <span>Old Password:</span>
            <input type="password" name="update_pass" placeholder="Enter Previous Password" class="box">f
            <span>New Password:</span>
            <input type="password" name="new_pass" placeholder="Enter New Password" class="box">
            <span>Confirm Password:</span>
            <input type="password" name="confirm_pass" placeholder="Confirm New Password" class="box">
            <span>Middle Name:</span>
            <input type="text" name="update_middle_name" value="<?php echo $fetch['middle_name']; ?>" class="box">
            <span>DOB:</span>
            <input type="date" name="update_dob" value="<?php echo $fetch['dob']; ?>" class="box">
            <span>Parent/Guardian Name:</span>
            <input type="text" name="update_parent_name" value="<?php echo $fetch['parent_name']; ?>" class="box">
            <span>Address:</span>
            <input type="text" name="update_address" value="<?php echo $fetch['address']; ?>" class="box">
            <span>State:</span>
            <input type="text" name="update_state" value="<?php echo $fetch['state']; ?>" class="box">
            <span style="margin-bottom: 10px;">Are you an Indian citizen?</span>
            <div style="margin-top: 5px;"> <!-- Add some space between the text and the radio buttons -->
               <label style="margin-right: 10px;"><input type="radio" name="indian_citizen" value="Yes" <?php if($fetch['indian_citizen'] == 'Yes') echo 'checked'; ?>> Yes</label>
               <label><input type="radio" name="indian_citizen" value="No" <?php if($fetch['indian_citizen'] == 'No') echo 'checked'; ?>> No</label>
            </div>
            <span>High School</span>
            <input type="text" name="update_high_school" value="<?php echo $fetch['high_school']; ?>" class="box">
            <span>College:</span>
            <input type="text" name="update_college" value="<?php echo $fetch['college']; ?>" class="box">
            <span>Graduated from College?</span>
            <select name="update_graduated_college" class="box">
               <option value="">Select</option> <!-- Placeholder option -->
               <option value="Yes" <?php if($fetch['graduated_college'] == 'USA') echo 'selected'; ?>>Yes</option>
               <option value="No" <?php if($fetch['graduated_college'] == 'Canada') echo 'selected'; ?>>No</option>
            </select> 
            <span>Qualifications</span>
            <select name="update_qualifications" class="box">
               <option value="">Select</option> <!-- Placeholder option -->
               <option value="Yes" <?php if($fetch['qualifications'] == 'USA') echo 'selected'; ?>>PG -> M-tech, Msc, MBA</option>
               <option value="No" <?php if($fetch['qualifications'] == 'Canada') echo 'selected'; ?>>UG -> Btech, BSc, BBA </option>
               <option value="No" <?php if($fetch['qualifications'] == 'Canada') echo 'selected'; ?>>12th</option>
               <option value="No" <?php if($fetch['qualifications'] == 'Canada') echo 'selected'; ?>>10th</option>
            </select>



         </div>
      </div>
      
      <!-- Personal Details End -->
      <input type="submit" value="Update Profile" name="update_profile" class="btn">
   </form>

</div>

</body>
</html>
